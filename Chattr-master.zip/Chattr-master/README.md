Chattr
======
An elegant & speedy iOS7 chat app built with JavaScript & Framework7, using firebase to handle chat persistence.

Packaged as an HTML5 iOS app (Open in Safari, Click the share icon in the upper-left hand corner, and select `Add to Home Screen` to install to your device).

## Demo

https://f7-chat.firebaseapp.com/

## Native Build & App.io Preview

https://gonative.io/share/yeker
